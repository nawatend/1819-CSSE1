﻿using System;

namespace lesweek5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            //string always small -- string is array van char
            string tekst = " This is string ";

            int length = tekst.Length;

            for (int i = 0; i < length; i++)
            {
                Console.WriteLine(tekst[i]);

            }
            Console.WriteLine(tekst.ToUpper());
            Console.WriteLine(tekst.ToLower());

            //read word by wrod
            string[] woorden = tekst.Split(' ');
            foreach (var woord in woorden)
            {

                Console.WriteLine(woord);
            }


            //remove spaces. Write char within ' ' 
            //this removes every spaces
            Console.WriteLine(tekst.Replace(" ", ""));

            //this removes before and after spaces a string
            //Console.WriteLine(tekst);
            Console.WriteLine(tekst.Trim(' '));

            string wachtword = "testww";
            bool test1 = wachtword.Contains('b');
            Console.WriteLine(test1);
            bool test2 = wachtword.Contains('b');

        }
    }
}
